# Third-party notices

SalesAutoMate VectorForge does not claim ownership of third-party software. A build may link to **libwebp**, **libavif**, **libtiff**, **libpng**, **libjpeg-turbo**, or **nlohmann-json** (the latter is compatible with the report design but is not required by this implementation). Their own licenses and notices apply.

Deployments may detect optional executables including **VTracer** (alternate tracer/comparison), **ImageMagick** (emergency decode), **Ghostscript** (EPS rasterization), **pdftocairo** (EPS/PDF route), **pstoedit**, and **Inkscape** (EPS/vector route). Those programs are not bundled, invoked as the default architecture, or owned by this project. Operators are responsible for installation, licensing, and security review.

Consult the upstream distribution of each component for authoritative copyright and license text. Dynamic or static linking choices can create different compliance obligations.
