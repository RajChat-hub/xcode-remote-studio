# SalesAutoMate(TM) VectorForge

**Version 1.0.0-alpha · Rajdeep Chatterjee**

SalesAutoMate VectorForge is a C++20 library and command-line engine that converts raster and container image formats into deterministic, editable SVG geometry. This repository is an **alpha/commercial-in-progress**, not a finished commercial 1.0 release. The default tracer is implemented inside VectorForge: output is made from vector paths, not an embedded copy of the source image.

VectorForge includes a native tracing engine. Current quality is significantly improved and moving toward commercial-grade output. Logo, icon, line-art, UI, poster, and flat-graphic output should now be much cleaner. Photo-grade output is improved but is still being refined toward VTracer-class quality; equality is not claimed.

## Why this is not a wrapper

The executable is a thin client of `libvectorforge`, but the library owns the conversion pipeline: signature-based format detection, RGBA normalization, native BMP/PNM/ICO/DDS parsing, Lab quantization, edge-aware connected regions, adjacency/hierarchy merging, hole extraction, corner detection, simplification, cubic fitting, SVG optimization, validation, reports, comparison rasterization, and batch orchestration. WebP, AVIF, TIFF, PNG, and JPEG are decoded through their dedicated libraries when present. External programs are never the default trace architecture.

```text
input → detect → native/library decode → RGBA → Lab quantize/threshold
      → Sobel/color edge map → protected-detail segmentation → guarded merge
      → contours/holes → corners → quadratic/cubic paths → optional optimization
      → SVG → clean/check/report/compare
```

## Format support

| Format | Decoder | Alpha scope |
|---|---|---|
| BMP | VectorForge native | Uncompressed 24/32-bit, top-down/bottom-up, padded rows |
| PPM/PGM | VectorForge native | P2, P3, P5, P6; 8/16-bit samples |
| ICO | VectorForge native | Directory selection and uncompressed 24/32-bit DIB frames |
| DDS | VectorForge native | Uncompressed 24/32-bit masked RGB(A), mip selection, DXT1/BC1; other BCn detected honestly |
| WebP | libwebp | Enabled only when CMake finds libwebp |
| AVIF/HEIF | libavif | Enabled only when CMake finds libavif |
| TIFF | libtiff | Page selection and RGBA normalization |
| PNG/JPEG | libpng/libjpeg | Convenience inputs when found |
| EPS | optional tools | Explicit preserve-vector or rasterize/trace workflow; no native PostScript VM |

Run `vectorforge doctor` for the exact capabilities of a particular binary.

## CLI quick start

```bash
vectorforge --help
vectorforge convert logo.webp -o logo.svg --preset logo-pro
vectorforge convert logo.png -o logo.svg --preset logo-master --gradient-mode auto --primitive-fit strong --compact-svg strong
vectorforge convert image.avif -o image.svg --preset photo-balanced
vectorforge convert scan.tiff --page 1 -o scan.svg
vectorforge convert app.ico --select-largest -o app.svg
vectorforge convert app.ico --list
vectorforge convert texture.dds --mipmap 0 -o texture.svg
vectorforge convert texture.dds --info
vectorforge convert input.bmp -o input.svg --preset logo
vectorforge convert input.ppm -o input.svg --preset lineart
vectorforge convert input.webp -o output.svg --report report.json
vectorforge batch assets/ --out svg/ --recursive --preset logo
vectorforge check logo.svg
vectorforge compare logo.webp logo.svg
vectorforge benchmark-logo logo.png --out-dir vf-out/logo-bench
vectorforge benchmark-vtracer logo.webp --out-dir vf-out/bench
vectorforge doctor
```

Accuracy-first presets are `trace-accurate`, `logo-vtrace-like`, `photo-accurate`, `poster-accurate`, `icon-accurate`, and `game-ui-accurate`. They retain separate region paths, use edge-protected light merging, and permit large SVGs. Compression-oriented presets (`logo-pro`, `logo-clean`, `photo-balanced`, and the other `*-pro`/`*-clean` modes) remain useful when size matters more than local fidelity. No preset claims equality with VTracer.

`logo-master` is the flagship structured-logo preset. It detects clean logo structure, uses a stable compact contour geometry pass, recognizes circle nodes, and fits confidence-gated SVG linear gradients only when measured variation justifies them. It deliberately declines gradients on effectively flat regions. Controls are `--gradient-mode`, `--primitive-fit`, `--logo-structure`, `--compact-svg`, `--size-priority`, `--fidelity-priority`, `--corner-preserve`, and `--gradient-threshold`.

On the real 1254×1254 `rift-logo.png`, generic `logo-vtrace-like` at the benchmark resolution produced 3,217 paths and 434,891 bytes. `logo-master` produced 18 paths and 235,083 bytes with 99.37% approximate color similarity, 99.50% tolerant edge F1, and a `Very close` verdict. Auto gradient count was zero because measured body variation was below the confidence threshold; forced/generated gradient fixtures prove gradient emission separately. Strict edge IoU remains 41.53%, so near-identical/VTracer equality is not claimed.

Accuracy controls include `--accuracy low|medium|high|ultra`, `--edge-mode normal|strong|vtrace-like`, `--merge-mode none|light|normal|strong`, `--simplify-mode none|light|normal|strong`, `--curve-fit none|quadratic|cubic`, `--curve-error`, `--edge-threshold`, `--detail-threshold`, `--allow-many-paths`, and `--quality-budget fast|balanced|accurate|max`. Existing path, size, palette, detail, and SVG optimization controls remain. Only `--quality-budget fast`, `--max-dimension`, or `--preview-scale` can request downsampling.

`compare INPUT OUTPUT.svg` reports color similarity, mean difference, an SSIM-like luminance score, strict edge IoU, one-pixel-tolerant edge F1/recall/precision, path count, colors, size, and an honest verdict. Strict edge overlap below 60% produces a warning even when color similarity is high. These remain engineering indicators, not standardized perceptual scores.

## Measured accuracy direction

The earlier compression pass produced small but visibly over-generalized output. On the real 640×426 BMP, this accuracy pass deliberately permits much more geometry:

| Output | Paths | SVG size | Color similarity | Strict edge IoU | Tolerant edge recall |
|---|---:|---:|---:|---:|---:|
| old `bmp-logo-clean.svg` | 39 | 327,345 B | 89.63% | 22.52% (legacy) | 60.96% |
| old `bmp-edge-detail.svg` | 128 | 2,291,571 B | 93.89% | 33.84% (legacy) | 75.43% |
| new `logo-vtrace-like` | 36,228 | 3,337,109 B | 91.96% | 46.87% | 93.44% |
| new `photo-accurate` | 49,961 | 4,349,620 B | 93.18% | 48.67% | 94.28% |

Legacy strict-IoU figures and current tolerant metrics are exposed separately rather than silently substituted. The new outputs preserve substantially more edge evidence, but strict overlap is still below 60%, so VectorForge labels them `Posterized`, not near-VTracer quality. Accuracy improved; the remaining gap is explicit.

Every CLI conversion either prints `Converted ...` and returns 0 after writing the SVG, or prints `ERROR: ...` and returns nonzero. Exit codes are 1 for conversion failure, 2 for bad arguments, 3 for unsupported formats/features, and 4 for internal errors. `--report` is honored on conversion failures.

## Build and test

```bash
cmake -S . -B build -G Ninja
cmake --build build
ctest --test-dir build --output-on-failure
```

Optional features can be disabled explicitly, for example `-DVECTORFORGE_WITH_AVIF=OFF`. A missing optional library also results in a clean disabled build, not fake format support.

With vcpkg on Windows:

```bat
cmake -S . -B build -G Ninja -DCMAKE_TOOLCHAIN_FILE=%VCPKG_ROOT%/scripts/buildsystems/vcpkg.cmake
cmake --build build
ctest --test-dir build --output-on-failure
```

For MSYS2/MinGW64 or UCRT64, install CMake, Ninja, a C++20 compiler, and whichever codec development packages are wanted. Keep the compiler, Ninja, and codec packages in the same MSYS2 environment. The native core has no codec dependency.

## Library API

Include `<vectorforge/vectorforge.h>`, populate `ConvertOptions`, and call `vectorforge::convert`. Lower-level applications can use format detection and `decode_to_bitmap`, or the tracing/SVG module headers independently. Failures are returned in `ConvertReport::errors`; decoder helpers throw `vectorforge::Error` for direct callers.

## SVG safety and limitations

The writer emits a namespace, `viewBox`, deterministic path ordering, uppercase `#RRGGBB` fills, optional opacity, and no raster image. The cleaner removes empty paths, external URL attributes, and image elements. The validator checks the root, `viewBox`, vector content, external references, embedded rasters, path count, and size.

The tracer uses perceptual Lab median-cut, region adjacency/hierarchy merging, micro-region attachment, exterior and hole contours, hard-corner classification, cubic SVG fitting, and compatible-fill compound-path optimization. It can still show region or edge artifacts on photographic material. DXT1/BC1 is decoded; later BCn variants are reported unsupported. See [commercial limitations](docs/COMMERCIAL_LIMITATIONS.md).

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Tracing engine](docs/TRACING_ENGINE.md)
- [Format support](docs/FORMAT_SUPPORT.md)
- [WebP, AVIF, and TIFF](docs/WEBP_AVIF_TIFF.md)
- [ICO and DDS](docs/ICO_DDS_SUPPORT.md)
- [EPS pipeline](docs/EPS_PIPELINE.md)
- [CLI reference](docs/CLI_REFERENCE.md)
- [Commercial limitations](docs/COMMERCIAL_LIMITATIONS.md)

Copyright © 2026 Rajdeep Chatterjee. All rights reserved.
