# EPS pipeline

EPS is PostScript, not a raster container. VectorForge therefore keeps it outside the native bitmap decoder contract.

`--preserve-vector` is designed for pstoedit or Inkscape-style conversion. `--rasterize DPI --trace` is designed for a Ghostscript raster followed by the built-in VectorForge tracer. `doctor` detects pstoedit, Ghostscript, pdftocairo, and Inkscape.

For the v1.0 secure build, automatic external process execution is intentionally disabled: an EPS request reports whether a suitable tool is present and returns a clear error. This avoids implicit execution of untrusted PostScript. A future hardened worker can add timeouts, sandboxing, page limits, and explicit operator policy before enabling the route.
