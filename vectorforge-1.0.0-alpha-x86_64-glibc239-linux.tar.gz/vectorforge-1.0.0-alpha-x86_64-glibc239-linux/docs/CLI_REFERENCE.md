# CLI reference

Global commands are `--help`, `--version`, `info`, `doctor`, `formats`, and `backends`.

`convert INPUT -o OUTPUT.svg` accepts compression and accuracy presets. Accuracy controls are `--accuracy low|medium|high|ultra`, `--edge-mode normal|strong|vtrace-like`, `--merge-mode none|light|normal|strong`, `--simplify-mode none|light|normal|strong`, `--curve-fit none|quadratic|cubic`, `--curve-error N`, `--edge-threshold N`, `--detail-threshold N`, `--allow-many-paths`, and `--quality-budget fast|balanced|accurate|max`. Existing decode, palette, path budget, target size, threshold, smoothing, page, mip, ICO, report, validation, and fallback controls remain.

`compare INPUT OUTPUT.svg` decodes the source and internally rasterizes supported VectorForge SVG path commands. It prints color similarity, mean difference, structural estimate, SSIM-like luminance, strict edge IoU, one-pixel-tolerant edge F1/recall/precision, path count, color estimate, size, and a verdict. Strict overlap below 60% warns rather than implying near-VTracer fidelity.

`benchmark-vtracer INPUT --out-dir DIR` is optional. If VTracer is missing it prints `VTracer not found; benchmark skipped.` If present, it runs VectorForge’s native accurate preset and the external tool as separate benchmark candidates, then compares both. VTracer is never the normal trace backend.

`logo-master` options are `--gradient-mode off|auto|force`, `--primitive-fit off|auto|strong`, `--logo-structure auto|force`, `--compact-svg off|auto|strong`, `--size-priority quality|balanced|compact`, `--fidelity-priority balanced|high|max`, `--corner-preserve low|medium|high|max`, and `--gradient-threshold N`.

`benchmark-logo INPUT --out-dir DIR` writes generic accurate and logo-master SVGs plus `benchmark-logo.txt`. It compares color, strict/tolerant edges, paths, layers, gradients, primitives, bytes, compactness, and verdict. VTracer is added only when installed; otherwise the report records a clean skip.

`batch INPUT_DIR --out OUTPUT_DIR [--recursive] [--preset NAME] [--fail-fast]` preserves relative paths, continues after failures, and writes `batch-report.json`. It skips `build`, `docs`, `.git`, and `vf-out` unless named with `--include-dir`.

`check FILE.svg` performs structural and embedded-content checks. ICO `--list` and DDS `--info` inspect containers without requiring output.

Exit codes: 0 success; 1 conversion failure; 2 bad arguments; 3 unsupported format/feature; 4 internal error.
