# WebP, AVIF, and TIFF

WebP is decoded directly with libwebp into RGBA. AVIF/HEIF uses libavif decoding plus its YUV-to-RGBA conversion. TIFF uses libtiff directory navigation (`--page`, zero-based) and oriented RGBA raster reading.

The CMake switches are `VECTORFORGE_WITH_WEBP`, `VECTORFORGE_WITH_AVIF`, and `VECTORFORGE_WITH_TIFF`. `ON` requests detection; it does not manufacture support. If a package is absent, the binary still builds and its decoder returns a precise disabled-feature error. `doctor` displays the compiled status.

Animated WebP/AVIF frames, advanced HEIF item selection, TIFF sub-IFDs, specialized scientific samples, and full color-profile management are future work.
