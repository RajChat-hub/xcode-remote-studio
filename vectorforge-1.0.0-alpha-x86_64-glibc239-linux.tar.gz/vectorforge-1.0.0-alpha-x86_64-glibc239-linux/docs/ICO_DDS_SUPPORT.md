# ICO and DDS support

The ICO parser validates the file directory and every frame extent. `--list` reports size, depth, and DIB/PNG payload type. Selection uses `--ico-size N`, `--select-largest`, or the first frame by default. Native decode handles uncompressed 24/32-bit DIB pixels and a 1-bit AND mask for 24-bit images.

The DDS parser validates the classic 124-byte header. `--info` reports dimensions, mip count, format, and compression state. Uncompressed 24/32-bit formats are decoded from declared channel masks; `--mipmap N` advances through packed mip levels. DXT1/BC1 is decoded natively, including partial 4×4 edge blocks and the BC1 one-bit transparent index mode. DXT3/DXT5 and later BCn formats are detected and rejected by name.

DX10 headers, cubemap face selection, BC2–BC7, and palette ICO remain outside the alpha subset.
