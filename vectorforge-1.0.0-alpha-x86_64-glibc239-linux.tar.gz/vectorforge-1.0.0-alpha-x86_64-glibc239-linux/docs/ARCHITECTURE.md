# Architecture

VectorForge separates decoding from tracing. `detect_format` uses signatures first and extensions only as a diagnostic fallback. A decoder produces a validated row-major RGBA bitmap. No decoder emits SVG and no tracer knows about input containers.

The trace stage thresholds a luminance mask in BW mode or builds a deterministic palette and label map in color mode. Four-connected components isolate regions. Pixel-cell edges are oriented and joined into closed boundaries, then simplified and optionally smoothed. The writer serializes shapes in stable palette/component order. Cleaner, validator, and JSON reporting are downstream stages.

`libvectorforge` owns the pipeline. The CLI handles argument policy and recursive discovery; it does not shell out to trace raster images. Optional codec libraries are compile-time capabilities surfaced by `doctor`.

Safety bounds reject malformed dimensions, truncated payloads, invalid offsets, unsupported compression, and inconsistent RGBA storage. Writes create parent directories and report failures instead of silently dropping output.
