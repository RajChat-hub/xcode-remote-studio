# Built-in tracing engine

VectorForge’s tracer is native and commercial-in-progress. Accuracy-first output is materially closer to source edges than the previous compression pass, but it is not claimed equal to VTracer.

## Pipeline

RGBA is alpha-filtered, then color input is clustered with deterministic weighted median-cut in CIE Lab space. A luminance-Sobel plus color/alpha gradient map protects important boundaries. High/ultra accuracy modes apply conservative 3×3 label stabilization only away from protected edges. Lab labels then feed four-connected segmentation.

Region adjacency records shared-border length and average edge strength. A merge requires compatible color and a weak boundary. Bright high-contrast, edge-supported, alpha-supported, and locally salient components are protected. `none`, `light`, `normal`, and `strong` policies make that tradeoff explicit. Regions retain exterior loops, holes, deterministic ordering, and a larger-adjacent parent relationship.

Ramer–Douglas–Peucker simplification is controlled by a mode and an error ceiling. Direction-change classification marks hard corners before smoothing. Smooth spans can be emitted as quadratic or cubic Bézier segments while corner endpoints remain linear. Accuracy presets leave fill regions as separate SVG paths; compression presets may combine same-fill regions into compound even-odd paths.

## Controls and presets

`--edge-mode` and `--edge-threshold` control boundary protection. `--merge-mode` selects merging policy. `--simplify-mode`, `--curve-fit`, and `--curve-error` govern contour fidelity. `--detail-threshold` governs salient component protection. `--allow-many-paths` prevents conversion failure and aggressive hard limiting when fidelity needs more geometry. `--quality-budget max` strengthens protection; `fast` may downsample images larger than 1024 pixels.

Accuracy presets are `trace-accurate`, `logo-vtrace-like`, `photo-accurate`, `poster-accurate`, `icon-accurate`, and `game-ui-accurate`. Compression presets remain available for smaller output. Detail and accuracy levels are `low`, `medium`, `high`, and `ultra`.

## Honest remaining gap

The internal curve emitter is adaptive through contour point splitting and error-bounded simplification, but it is not yet a global least-squares fitter. Remaining work includes subpixel anti-alias contour placement, recursive Bézier error measurement, stronger topology repair, and a better region occlusion model.

## Logo-master structured path

`logo-master` first scores coarse color diversity, local smoothness, and dominant corner/background area. Forced mode bypasses detection. Geometry uses a bounded, proven logo contour pass and exact-fill compound paths; it does not retain tens of thousands of accurate-mode regions.

The semantic analysis separates background, purple/body-like pixels, and cyan/accent-like pixels. A spatial luminance regression estimates a linear gradient direction and samples three, five, or seven stops according to size/fidelity priority. Auto mode emits a gradient only when stop variation exceeds `--gradient-threshold`; the real logo is effectively flat and correctly remains flat-filled. Circle recognition uses directional distance maxima and coverage validation. Recognized-node counts are recorded without overlaying duplicate circles when the compound contour already represents them more accurately.

Cross-color compound merging is intentionally prohibited: differently nested antialias layers can change even-odd topology if collapsed together. Compactness comes from stable exact-fill grouping, bounded trace resolution, command precision, and omission of unnecessary metadata.
