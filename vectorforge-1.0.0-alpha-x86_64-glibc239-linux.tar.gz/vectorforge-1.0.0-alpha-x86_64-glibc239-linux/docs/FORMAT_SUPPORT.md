# Format support

Native, always-built support covers BMP, PPM/PGM, ICO directories/DIB frames, and DDS headers, uncompressed channel masks, and DXT1/BC1 blocks. Library support covers WebP, AVIF/HEIF, TIFF, PNG, and JPEG only when the corresponding library is found during configuration.

Unsupported data is rejected explicitly. Examples include BMP compression, palette ICO frames, later DDS BCn/DXT variants, an out-of-range mip/page, and malformed dimensions. Embedded-PNG ICO uses libpng when compiled. `formats` describes product scope; `doctor` describes the current binary.

All successful decoders return normalized, non-premultiplied, row-major RGBA with a top-left origin. Format-specific metadata outside selection controls is not retained in v1.0.
