# Commercial-in-progress limitations

The accuracy upgrade recovers substantially more local edge evidence than the earlier compression-first output. It does not prove equality with VTracer or perfect source reconstruction.

- On the tested 640×426 BMP, accuracy modes reach about 92–93% color similarity and 93–94% tolerant edge recall, but strict edge IoU remains 46.87–48.67%, below the project’s 60% guardrail.
- Same-fill compound paths are disabled by accuracy presets because a tiny element count concealed geometric complexity and made quality evaluation misleading.
- Edge-aware region merging is adjacency- and Lab-based, not a semantic vision model. Strong textures can still fragment into many paths; aggressive user thresholds can still absorb detail.
- Cubic handles use local tangents. They are not globally optimized least-squares curves and can deviate at complex inflections.
- `--target-size-kb` is a compression request and can conflict with accuracy-first goals.
- Accurate photo output is intentionally large and CPU/memory intensive.
- BC2–BC7, DX10 DDS, palette ICO, advanced HEIF/TIFF selection, and complete ICC workflows remain incomplete.
- The compare rasterizer supports VectorForge’s generated path subset; its SSIM-like and edge metrics are engineering diagnostics, not scientific certification.
- EPS process execution remains disabled pending sandboxing.

Next steps toward near-VTracer quality are subpixel antialias-aware contour placement, recursive least-squares cubic fitting, topology repair, region occlusion optimization, tiled tracing, and larger visual benchmark suites.

`logo-master` is strongest on clean, limited-palette marks. Forced use on a photo can create a compact but posterized result; the CLI reports that honestly. The real logo benchmark is `Very close`, not `Near-identical`: strict edge IoU remains 41.53% even though color similarity and tolerant edge F1 exceed 99%. Auto gradients are confidence-gated because applying gradients to nested antialias compound layers can damage topology. Radial gradients and explicit boolean path subtraction are not implemented in this pass.
